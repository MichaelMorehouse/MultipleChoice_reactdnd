export const ItemTypes = {
    ANSWERCHOICE: 'answerchoice'
}

export const PlaceholderText = 'Drop your answer here'