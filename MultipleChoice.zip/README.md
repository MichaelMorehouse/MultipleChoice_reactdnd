A simple template for multiple choice questions using [React](https://reactjs.org/) and [React Drag n Drop](https://react-dnd.github.io/react-dnd/). Created using `create-react-app`

To run the app:
In a node.js terminal, navigate to the main repository directory and enter `npm start`

All application state is handled through the Question component. State managers like Redux may require a different pattern.